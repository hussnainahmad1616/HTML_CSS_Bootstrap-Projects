
const asyncHandler = require("express-async-handler")
const PaymentModel = require("../models/payment");

const userPayment = asyncHandler(async (req,res )=>{
    const {name,email,address,city,state,zipCode,cardNumber,expMonth,expYear,cvv} = req.body;
    if(!name,!email,!address,!city,!state,!zipCode,!cardNumber,!expMonth,!expYear,!cvv){
        res.status(400);
        throw new Error("Please Enter All The Fields")
    }
    const userExist= await PaymentModel.findOne({email})
    if(userExist){
        res.status(400);
        throw new Error("Email Already Used")
    }
    const user= await PaymentModel.create({
        name,
        email,
        address,
        city,
        state,
        zipCode,
        cardNumber,
        expMonth,
        expYear,
        cvv
    })
    if(user){
        res.status(201).json({
            _id:user.id,
            name:user.name,
            address:user.address,
            city:user.city,
            state:user.state,
            zipCode:user.zipCode,
            cardNumber:user.cardNumber,
            expMonth:user.expMonth,
            expYear:user.expYear,
            cvv:user.cvv,
        })
    }
    else{
        res.status(400);
        throw new Error("Payment Failed")
    }
})

module.exports = {userPayment}