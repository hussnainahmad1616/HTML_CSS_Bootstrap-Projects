require("./config");
const mongoose = require("mongoose");
const express = require("express")
const cors = require("cors");
const app = express();
const userRoutes = require('./userRoutes/userRoute')
app.use(express.json())
app.use(cors());

// app.post('/register',(async (req,res)=>{
//     let data = await registerModel.insertMany(req.body);
//     res.send(data);
    
// }))
app.use('/user',userRoutes);
// /user/login 
// /user/register 


app.listen(5000);
