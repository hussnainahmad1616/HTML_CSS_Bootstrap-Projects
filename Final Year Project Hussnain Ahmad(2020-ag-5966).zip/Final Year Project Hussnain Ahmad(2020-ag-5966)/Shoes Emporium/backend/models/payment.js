const mongoose = require("mongoose");
let paymentSchema = new mongoose.Schema({
    name:String,
    email:String,
    address:String,
    city:String,
    state:String,
    zipCode:String,
    cardNumber:String,
    expMonth:String,
    expYear:String,
    cvv:String,
})

let paymentModel = mongoose.model("payments",paymentSchema);
module.exports  =paymentModel;