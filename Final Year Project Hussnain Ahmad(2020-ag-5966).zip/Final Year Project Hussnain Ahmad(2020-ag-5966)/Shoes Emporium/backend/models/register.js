const mongoose = require("mongoose");
let registerSchema = new mongoose.Schema({
    name:String,
    email:String,
    phone:String,
    gender:String,
    password:String,
})

let registerModel = mongoose.model("registers",registerSchema);
module.exports  =registerModel;