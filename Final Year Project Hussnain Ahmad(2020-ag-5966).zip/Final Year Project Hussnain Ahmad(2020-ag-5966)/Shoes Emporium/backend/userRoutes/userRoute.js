const express = require("express");
const {registerUser,authUser} = require("../controllers/userController")
const {userPayment} = require("../controllers/paymentController")
const router = express.Router();

router.route('/register').post(registerUser)
router.route('/login').post(authUser);
router.route('/payment').post(userPayment);


module.exports = router;