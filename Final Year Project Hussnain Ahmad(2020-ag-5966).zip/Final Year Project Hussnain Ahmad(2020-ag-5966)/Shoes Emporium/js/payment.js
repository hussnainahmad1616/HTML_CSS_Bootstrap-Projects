function submitForm() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const address = document.getElementById("address").value;
    const city = document.getElementById("city").value;
    const state = document.getElementById("state").value;
    const zipCode = document.getElementById("zipCode").value;
    const cardNumber = document.getElementById("cardNumber").value;
    const expMonth = document.getElementById("expMonth").value;
    const expYear = document.getElementById("expYearSelect").value;
    const cvv = document.getElementById("cvv").value;

    const formData = {
        name: name,
        email: email,
        address: address,
        city: city,
        state: state,
        zipCode: zipCode,
        cardNumber: cardNumber,
        expMonth: expMonth,
        expYear: expYear,
        cvv: cvv
    };

    console.log(formData);
    fetch("http://localhost:5000/user/payment", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error("Payment Unsuccessfull");
        }
        return response.json();
    })
    .then((data) => {
        alert("Payment Successfully!")
    })
    .catch((error) => {
        console.error("Error:", error);
        alert(error.message)
    });
}