const asyncHandler = require("express-async-handler")
const User = require("../models/register");


const registerUser = asyncHandler(async (req,res )=>{
    const {name,email,phone,gender,password} = req.body;
    if(!name,!email,!phone,!gender,!password){
        res.status(400);
        throw new Error("Please Enter All The Fields")
    }
    const userExist= await User.findOne({email})
    if(userExist){
        res.status(400);
        throw new Error("User Already Exists")
    }
    const user= await User.create({
        name,
        email,
        phone,
        gender,
        password
    })
    if(user){
        res.status(201).json({
            _id:user.id,
            name:user.name,
            email:user.email,
            phone:user.phone,
            gender:user.gender,
            password:user.password
        })
    }
    else{
        res.status(400);
        throw new Error("Failed To Create The User")
    }
})


const authUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (user && user.password === password) { 
        res.status(201).json({
            _id: user.id,
            name: user.name,
            email: user.email,
            phone: user.phone,
            gender: user.gender,
            password: user.password
        });
    } else {
        res.status(401);
        throw new Error("User Not Found");
    }
});

module.exports = {registerUser,authUser}