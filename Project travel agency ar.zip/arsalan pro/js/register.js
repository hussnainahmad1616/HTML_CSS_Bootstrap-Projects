function register(event) {
    event.preventDefault();
    let registerName = document.getElementById("registerName").value;
    let registerEmail = document.getElementById("registerEmail").value;
    let registerPhone = document.getElementById("registerPhone").value;
    let registerSelect = document.getElementById("registerSelect").value;
    let registerPass = document.getElementById("registerPass").value;
    let registerConfirmPass = document.getElementById("registerConfirmPass").value;

    if(registerPass !== registerConfirmPass){
        alert("Passwords do not match");
        return; 
    }
    if(registerPass.length < 6){
        alert("Password must be at least 8 characters long");
        return;
    }

    let obj = {
        name: registerName,
        email: registerEmail,
        phone: registerPhone,
        gender: registerSelect,
        password: registerPass,
    };

    fetch("http://localhost:5000/user/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        return response.json();
    })
    .then((data) => {
        alert("Registration Successfully!")
    })
    .catch((error) => {
        console.error("Error:", error);
        if (error.message === "Network response was not ok") {
            alert("Network error. Please try again later.");
        } else {
            error.json().then((errorMessage) => {
                alert(errorMessage.message);
            });
        }
    });
}


// login user function 
function login(event) {
    event.preventDefault();
    let loginEmail = document.getElementById("loginEmail").value;
    let loginPass = document.getElementById("loginPass").value;
    let obj = {
        email: loginEmail,
        password: loginPass
    };

    fetch("http://localhost:5000/user/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error("User Not Present");
        }
        return response.json();
    })
    .then((data) => {
        alert("Login SuccessFully")
    })
    .catch((error) => {
        console.error("Error:", error);
    });
}
